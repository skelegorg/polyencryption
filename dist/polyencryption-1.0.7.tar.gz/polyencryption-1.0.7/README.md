# polyencryption
this module allows for .txt file encryption and decryption through use of a key.
